//
//  NSString+StringWithRect.m
//  YXCoreMail
//
//  Created by ljm on 2018/8/8.
//  Copyright © 2018年 yxtech.ios. All rights reserved.
//

#import "NSString+StringWithRect.h"

@implementation NSString (StringWithRect)

- (CGSize)sizeWithLabelWidth:(CGFloat)width font:(UIFont *)font{
    
    NSDictionary *dict=@{NSFontAttributeName : font};
    CGRect rect=[self boundingRectWithSize:CGSizeMake(width, MAXFLOAT) options:(NSStringDrawingUsesLineFragmentOrigin) attributes:dict context:nil];
    CGFloat sizeWidth=ceilf(CGRectGetWidth(rect));
    CGFloat sizeHieght=ceilf(CGRectGetHeight(rect));
    return CGSizeMake(sizeWidth, sizeHieght);
}

@end
