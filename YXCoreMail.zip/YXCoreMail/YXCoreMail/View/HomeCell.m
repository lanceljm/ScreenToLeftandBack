//
//  HomeCell.m
//  YXCoreMail
//
//  Created by ljm on 2018/8/7.
//  Copyright © 2018年 yxtech.ios. All rights reserved.
//

#import "HomeCell.h"

@implementation HomeCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    
    self.backLogLab.layer.cornerRadius = 10;
    self.backLogLab.layer.masksToBounds = YES;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}

- (void)setBackLog:(NSInteger)backLog
{
    _backLog = backLog;
    if (backLog < 1) {
        self.backLogLab.hidden = YES;
    }else
    {
        self.backLogLab.hidden = NO;
        self.backLogLab.text = [NSString stringWithFormat:@"%ld",(long)backLog];
    }
}

- (void)setTotal:(NSInteger)total
{
    _total = total;
    if (total < 1) {
        self.totalLab.hidden = YES;
    }else
    {
        self.totalLab.hidden = NO;
        self.totalLab.text = [NSString stringWithFormat:@"%ld",(long)total];
    }
}

@end
