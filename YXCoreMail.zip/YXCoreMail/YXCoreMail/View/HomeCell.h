//
//  HomeCell.h
//  YXCoreMail
//
//  Created by ljm on 2018/8/7.
//  Copyright © 2018年 yxtech.ios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;
@property (weak, nonatomic) IBOutlet UILabel *titleLab;
@property (weak, nonatomic) IBOutlet UILabel *backLogLab;
@property (weak, nonatomic) IBOutlet UILabel *totalLab;

@property ( assign , nonatomic ) NSInteger  backLog ;
@property ( assign , nonatomic ) NSInteger  total ;

@end
