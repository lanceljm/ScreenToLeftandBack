//
//  ListCell.m
//  YXCoreMail
//
//  Created by ljm on 2018/8/8.
//  Copyright © 2018年 yxtech.ios. All rights reserved.
//

#import "ListCell.h"

@implementation ListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.logoTitleLab.layer.cornerRadius = 20.f;
    self.logoTitleLab.layer.masksToBounds = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}


- (void)setModel:(ListModel *)model
{
    _model = model;
    
    self.logoTitleLab.text = [NSString stringWithFormat:@"%@",model.logo];
    self.nameLab.text = [NSString stringWithFormat:@"%@",model.name];
    self.timeLab.text = [NSString stringWithFormat:@"%@",model.time];
    self.titleLab.text = [NSString stringWithFormat:@"%@",model.title];
    self.contentLab.text = [NSString stringWithFormat:@"%@",model.content];
}

@end
