//
//  ThemeCell.h
//  YXCoreMail
//
//  Created by ljm on 2018/8/8.
//  Copyright © 2018年 yxtech.ios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThemeCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *titleLab;
@property (weak, nonatomic) IBOutlet UILabel *timeLab;

@end
