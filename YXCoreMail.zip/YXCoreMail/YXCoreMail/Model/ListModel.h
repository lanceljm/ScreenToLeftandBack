//
//  ListModel.h
//  YXCoreMail
//
//  Created by ljm on 2018/8/8.
//  Copyright © 2018年 yxtech.ios. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ListModel : NSObject

@property ( copy , nonatomic ) NSString * logo ;
@property ( copy , nonatomic ) NSString * name ;
@property ( copy , nonatomic ) NSString * time ;
@property ( copy , nonatomic ) NSString * title ;
@property ( copy , nonatomic ) NSString * content ;

+ (instancetype)modelWithDict:(NSDictionary *)dict;

@end
