//
//  ListModel.m
//  YXCoreMail
//
//  Created by ljm on 2018/8/8.
//  Copyright © 2018年 yxtech.ios. All rights reserved.
//

#import "ListModel.h"

@implementation ListModel

+ (instancetype)modelWithDict:(NSDictionary *)dict
{
    ListModel *model = [[self alloc] init];
    [model setValuesForKeysWithDictionary:dict];
    return model;
    
}


@end
