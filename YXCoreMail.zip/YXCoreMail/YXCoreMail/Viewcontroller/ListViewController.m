//
//  ListViewController.m
//  YXCoreMail
//
//  Created by ljm on 2018/8/8.
//  Copyright © 2018年 yxtech.ios. All rights reserved.
//

#import "ListViewController.h"
#import "MainBodyViewController.h"
#import "NewViewController.h"
#import "ListCell.h"
#import "ListModel.h"

@interface ListViewController ()<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>

@property ( strong , nonatomic ) UITableView * selfTableview ;

@property ( strong , nonatomic ) UIView * bottomView;

@property ( strong , nonatomic ) NSArray * dataArray ;

@end

@implementation ListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//    [self setupWithLeft];
    [self setupWithRiht];
    [self initWithControl];
    
}

#pragma mark -- initWithControl
- (void) initWithControl
{
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self.view addSubview:self.selfTableview];
    [self.view addSubview:self.bottomView];
    
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 120, 44)];
    btn.center = self.bottomView.center;
    //    btn.backgroundColor = [UIColor redColor];
    [btn setImage:[UIImage imageNamed:@"Write"] forState:UIControlStateNormal];
    [btn setTitle:@"写新邮件" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor colorWithRed:21/255.0 green:132/255.0 blue:254/255.0 alpha:1.f] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(newMailWithAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    
    UITapGestureRecognizer *gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(newMailWithAction:)];
    [self.bottomView addGestureRecognizer:gesture];
}

#pragma mark -- newMailWithAction
- (void) newMailWithAction : (UIButton *) sender
{
    NSLog(@"点击了新启邮件");
    NewViewController *vc = [[NewViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark -- setupWithLeft
- (void) setupWithLeft
{
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 25, 20)];
    [btn setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(backWithAction) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
}

#pragma mark -- backWithAction
- (void) backWithAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -- setupWithRiht
- (void) setupWithRiht
{
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 20, 20)];
    [btn setImage:[UIImage imageNamed:@"more_grey"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(setupWithAction) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    
}

#pragma mark -- setupWithAction
- (void) setupWithAction
{
    NSLog(@"点击了更多");
}

#pragma mark -- uitableview delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 48;
}

- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 48)];
    view.backgroundColor = [UIColor whiteColor];
    
    UITextField *field = [[UITextField alloc] initWithFrame:CGRectMake(16, 8, self.view.frame.size.width - 32, 32)];
    field.placeholder = @"  🔍 搜索";
    field.delegate = self;
    field.layer.cornerRadius = 5;
    field.layer.masksToBounds = YES;
    field.backgroundColor = self.selfTableview.backgroundColor;
    [view addSubview:field];
    return view;
}


- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ListCell *cell = [[[NSBundle mainBundle] loadNibNamed:@"ListCell" owner:self options:nil] lastObject];
    
    ListModel *model = [ListModel modelWithDict:self.dataArray[indexPath.row]];
    
    cell.model = model;
    
    return cell;
}


#pragma mark -- uitableview datasource
- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    MainBodyViewController *vc = [[MainBodyViewController alloc] init];
    ListModel *model = [ListModel modelWithDict:self.dataArray[indexPath.row]];
    vc.model = model;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark -- textfiled delegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.view endEditing:YES];
    return YES;
}


#pragma mark -- getter
- (UITableView *)selfTableview
{
    if (!_selfTableview) {
        _selfTableview = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height - 48)];
        _selfTableview.backgroundColor = [UIColor colorWithRed:243/255.0 green:245/255.0 blue:249/255.0 alpha:1.f];
        _selfTableview.delegate = self;
        _selfTableview.dataSource = self;
        _selfTableview.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _selfTableview;
}
- (UIView *)bottomView
{
    if (!_bottomView) {
        _bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height - 48, self.view.frame.size.width, 48)];
        _bottomView.backgroundColor = [UIColor whiteColor];
        _bottomView.layer.borderWidth = 0.5f;
        _bottomView.layer.borderColor = [UIColor lightGrayColor].CGColor;
        
    }
    return _bottomView;
}

- (NSArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = @[
                                                 
                       @{@"logo":@"L",@"name":@"刘佳敏",@"time":@"9月1日",@"title":@"光宇车功能爱的那搜嘎科技卡伤筋动骨我偶尔网",@"content":@"阿萨德可发送卡了反馈说那边几十年村村民几点开始缴费基数代发new啊速度快放假；水电费离开发了"},
                       @{@"logo":@"S",@"name":@"刘佳",@"time":@"9月1日",@"title":@"光宇车功能爱的那搜嘎科技卡伤筋动骨我偶尔网",@"content":@"阿萨德可发送代理费卡机；的律师费等卡了反馈说那边几十年村村民几点开始缴费基数代发new啊速度快放假；水电费离开发了"},
                       @{@"logo":@"X",@"name":@"刘敏",@"time":@"9月2日",@"title":@"光宇车功能爱的那搜骨我偶尔网",@"content":@"阿萨德可发送几点开始缴费基数代发new啊速度快放假；水电费离开发了"},
                       @{@"logo":@"Q",@"name":@"罗加明",@"time":@"9月2日",@"title":@"光宇车功能爱的那搜骨我偶尔网",@"content":@"阿萨德可发送说那边几十年村村民几点开始缴费基数代发new啊速度快放假；水电费离开发了"},
                       @{@"logo":@"W",@"name":@"测试测试",@"time":@"9月3日",@"title":@"光宇车功能爱的那搜骨我偶尔网",@"content":@"阿萨德可发送说那边几十年村村民几点开始缴费基数代发new啊速度快放假；水电费离开发了"},
                       @{@"logo":@"R",@"name":@"陈云川",@"time":@"9月3日",@"title":@"光宇车功能爱的那搜骨我偶尔网",@"content":@"阿萨德可发送说那边几十年村村民几点开始缴费基数代发new啊速度快放假；水电费离开发了"},
                       @{@"logo":@"T",@"name":@"马云",@"time":@"9月4日",@"title":@"光",@"content":@"啊速度快放假；水电费离开发了"},
                       @{@"logo":@"P",@"name":@"Marry",@"time":@"9月2日",@"title":@"光宇车功能爱的那搜骨我偶尔网",@"content":@"阿"},
                       @{@"logo":@"M",@"name":@"curry",@"time":@"9月4日",@"title":@"光宇车功能爱的那搜骨我偶尔网",@"content":@"芳姐；啥来得及发送就能发；荆防颗粒；解放军奥is九分裤文件夹感受到看那看积分"},
                       @{@"logo":@"J",@"name":@"kobe",@"time":@"9月5日",@"title":@"光宇车功能爱的那搜骨我偶尔网",@"content":@"阿萨德可发送说那边几十年村村民几点开始缴费基数代发new啊速度快放假；水电费离开发了"}
                       ];
    }
    return _dataArray;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
