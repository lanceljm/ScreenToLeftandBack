//
//  MainBodyViewController.m
//  YXCoreMail
//
//  Created by ljm on 2018/8/8.
//  Copyright © 2018年 yxtech.ios. All rights reserved.
//

#import "MainBodyViewController.h"
#import "AddressCell.h"
#import "ThemeCell.h"
#import "contentCell.h"
#import "accessoryCell.h"
#import "NSString+StringWithRect.h"

@interface MainBodyViewController ()<UITableViewDelegate,UITableViewDataSource>

@property ( strong , nonatomic ) UITableView * selfTableview ;
@property ( strong , nonatomic ) UIView * bottomView ;

@end

@implementation MainBodyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    [self initWithControl];
//    [self setupWithLeft];
    [self setupWithRiht];
    [self setupWithBottomView];
    
}

#pragma mark -- initWithControl
- (void) initWithControl
{
    self.title = @"正文";
    self.view.backgroundColor = [UIColor whiteColor];
    
    
    [self.view addSubview:self.selfTableview];
    [self.view addSubview:self.bottomView];
}

#pragma mark -- setupWithLeft
- (void) setupWithLeft
{
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 25, 20)];
    [btn setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(backWithAction) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
}

#pragma mark -- backWithAction
- (void) backWithAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -- setupWithRiht
- (void) setupWithRiht
{
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 20, 20)];
    [btn setImage:[UIImage imageNamed:@"more_grey"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(setupWithAction) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    
}

#pragma mark -- setupWithAction
- (void) setupWithAction
{
    NSLog(@"点击了更多");
}

#pragma mark -- setupWithBottomView
- (void) setupWithBottomView
{
    /* 回复 */
    UIButton *replyBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 50, 50)];
    replyBtn.center = CGPointMake(self.view.frame.size.width / 8, self.bottomView.center.y);
    [replyBtn setImage:[UIImage imageNamed:@"reply"] forState:UIControlStateNormal];
    [replyBtn setTitle:@"回复" forState:UIControlStateNormal];
    [replyBtn setTitleColor:[UIColor colorWithRed:197/255.f green:197/255.f blue:197/255.f alpha:1.f] forState:UIControlStateNormal];
    replyBtn.titleLabel.font = [UIFont systemFontOfSize:12];
    replyBtn.tag = 0;
    [replyBtn addTarget:self action:@selector(clickedWithAction:) forControlEvents:UIControlEventTouchUpInside];
//    replyBtn.backgroundColor = [UIColor greenColor];
    replyBtn.imageEdgeInsets = UIEdgeInsetsMake(-20, 0, 0, -40);
    replyBtn.titleEdgeInsets = UIEdgeInsetsMake(20, 0, 0, 0);
    [self.view addSubview:replyBtn];
    
    /* 转发 */
    UIButton *forward = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 50, 50)];
    forward.center = CGPointMake(self.view.frame.size.width / 8 * 3, self.bottomView.center.y);
    [forward setImage:[UIImage imageNamed:@"forward"] forState:UIControlStateNormal];
    [forward setTitle:@"转发" forState:UIControlStateNormal];
    [forward setTitleColor:[UIColor colorWithRed:197/255.f green:197/255.f blue:197/255.f alpha:1.f] forState:UIControlStateNormal];
    forward.titleLabel.font = [UIFont systemFontOfSize:12];
    forward.tag = 1;
    [forward addTarget:self action:@selector(clickedWithAction:) forControlEvents:UIControlEventTouchUpInside];
    forward.imageEdgeInsets = UIEdgeInsetsMake(-20, 0, 0, -45);
    forward.titleEdgeInsets = UIEdgeInsetsMake(20, 0, 0, 0);
    [self.view addSubview:forward];
    
    /* 删除 */
    UIButton *deleteBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 50, 50)];
    deleteBtn.center = CGPointMake(self.view.frame.size.width / 8 * 5, self.bottomView.center.y);
    [deleteBtn setImage:[UIImage imageNamed:@"delete"] forState:UIControlStateNormal];
    [deleteBtn setTitle:@"删除" forState:UIControlStateNormal];
    [deleteBtn setTitleColor:[UIColor colorWithRed:197/255.f green:197/255.f blue:197/255.f alpha:1.f] forState:UIControlStateNormal];
    deleteBtn.titleLabel.font = [UIFont systemFontOfSize:12];
    deleteBtn.tag = 2;
    [deleteBtn addTarget:self action:@selector(clickedWithAction:) forControlEvents:UIControlEventTouchUpInside];
    deleteBtn.imageEdgeInsets = UIEdgeInsetsMake(-20, 0, 0, -40);
    deleteBtn.titleEdgeInsets = UIEdgeInsetsMake(20, 0, 0, 0);
    [self.view addSubview:deleteBtn];
    
    /* 更多 */
    UIButton *moreBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 50, 50)];
    moreBtn.center = CGPointMake(self.view.frame.size.width / 8 * 7, self.bottomView.center.y);
    [moreBtn setImage:[UIImage imageNamed:@"more"] forState:UIControlStateNormal];
    [moreBtn setTitle:@"更多" forState:UIControlStateNormal];
    [moreBtn setTitleColor:[UIColor colorWithRed:197/255.f green:197/255.f blue:197/255.f alpha:1.f] forState:UIControlStateNormal];
    moreBtn.titleLabel.font = [UIFont systemFontOfSize:12];
    moreBtn.tag = 3;
    [moreBtn addTarget:self action:@selector(clickedWithAction:) forControlEvents:UIControlEventTouchUpInside];
    moreBtn.imageEdgeInsets = UIEdgeInsetsMake(-20, 0, 0, -30);
    moreBtn.titleEdgeInsets = UIEdgeInsetsMake(20, 0, 0, 0);
    [self.view addSubview:moreBtn];
}


#pragma mark -- clickedWithAction
- (void) clickedWithAction : (UIButton *) sender
{
    switch (sender.tag) {
        case 0:
        {
            NSLog(@"点击了回复");
        }
            break;
        case 1:
        {
            NSLog(@"点击了转发");
        }
            break;
        case 2:
        {
            NSLog(@"点击了删除");
        }
            break;
        default:
        {
            NSLog(@"点击了更多");
        }
            break;
    }
}


#pragma mark -- uitableview delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 5;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    CGSize stringWithRect = [self.model.content sizeWithLabelWidth:self.view.frame.size.width - 32 font:[UIFont systemFontOfSize:18]];
    
    switch (indexPath.row) {
        case 0:
            return 48;
            break;
        case 1:
            return 48;
            break;
        case 2:
            return 60;
            break;
        case 3:
            return stringWithRect.height + 16;
            break;
        default:
            return 60;
            break;
    }
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    AddressCell *addressCell = [[[NSBundle mainBundle] loadNibNamed:@"AddressCell" owner:self options:nil] lastObject];
    ThemeCell *themeCell = [[[NSBundle mainBundle] loadNibNamed:@"ThemeCell" owner:self options:nil] lastObject];
    contentCell *contentCell = [[[NSBundle mainBundle] loadNibNamed:@"contentCell" owner:self options:nil] lastObject];
    accessoryCell *accessoryCell = [[[NSBundle mainBundle] loadNibNamed:@"accessoryCell" owner:self options:nil] lastObject];
    
    switch (indexPath.row) {
        case 0:
        {
            addressCell.typeLab.text = @"收件人:";
            addressCell.nameLab.text = @"罗加明";
            return addressCell;
        }
            break;
        case 1:
        {
            addressCell.typeLab.text = @"发件人:";
            addressCell.nameLab.text = [NSString stringWithFormat:@"%@",self.model.name];
            return addressCell;
        }
            break;
        case 2:
        {
            themeCell.titleLab.text = [NSString stringWithFormat:@"%@",self.model.title];//@"测试发送邮件，请勿回复！";
            themeCell.timeLab.text = [NSString stringWithFormat:@"%@",self.model.time];
            return themeCell;
        }
            break;
        case 3:
        {
            contentCell.contentLab.text = [NSString stringWithFormat:@"%@",self.model.content];
            return contentCell;
        }
            break;
            
        default:
        {
            accessoryCell.titleLab.text = [NSString stringWithFormat:@"%@",self.model.title];
            return accessoryCell;
        }
            break;
    }
}

#pragma mark -- getter
- (UITableView *)selfTableview
{
    if (!_selfTableview) {
        _selfTableview = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height - 60)];
        _selfTableview.backgroundColor = [UIColor whiteColor];
        _selfTableview.delegate = self;
        _selfTableview.dataSource = self;
        _selfTableview.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _selfTableview;
}

- (UIView *)bottomView
{
    if (!_bottomView) {
        _bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height - 60, self.view.frame.size.width, 60)];
        _bottomView.backgroundColor = [UIColor whiteColor];
        _bottomView.layer.borderColor = [UIColor lightGrayColor].CGColor;
        _bottomView.layer.borderWidth = 0.5f;
        
    }
    return _bottomView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
