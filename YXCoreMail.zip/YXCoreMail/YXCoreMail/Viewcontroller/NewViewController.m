//
//  NewViewController.m
//  YXCoreMail
//
//  Created by ljm on 2018/8/8.
//  Copyright © 2018年 yxtech.ios. All rights reserved.
//

#import "NewViewController.h"

@interface NewViewController ()

@end

@implementation NewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    [self initWithControl];
//    [self setupWithLeft];
    [self setupWithRiht];
    
}

#pragma mark -- initWithControl
- (void) initWithControl
{
    self.title = @"正文";
    self.view.backgroundColor = [UIColor whiteColor];
}

#pragma mark -- setupWithLeft
- (void) setupWithLeft
{
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 25, 20)];
    [btn setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(backWithAction) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
}

#pragma mark -- backWithAction
- (void) backWithAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -- setupWithRiht
- (void) setupWithRiht
{
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 20, 20)];
    [btn setImage:[UIImage imageNamed:@"more_grey"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(setupWithAction) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    
}

#pragma mark -- setupWithAction
- (void) setupWithAction
{
    NSLog(@"点击了更多");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
