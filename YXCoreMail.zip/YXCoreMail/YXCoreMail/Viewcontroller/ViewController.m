//
//  ViewController.m
//  YXCoreMail
//
//  Created by ljm on 2018/8/7.
//  Copyright © 2018年 yxtech.ios. All rights reserved.
//

#import "ViewController.h"
#import "HomeCell.h"
#import "ListViewController.h"
#import "NewViewController.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>

@property ( strong , nonatomic ) UITableView * selfTableview ;

@property ( strong , nonatomic ) UIView * bottomView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self initWithControl];
    [self setupWithRiht];
}

#pragma mark -- initWithControl
- (void) initWithControl
{
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.title = @"mayichao@im.yn.csg";
    
    [self.view addSubview:self.selfTableview];
    [self.view addSubview:self.bottomView];
    
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 120, 44)];
    btn.center = self.bottomView.center;
//    btn.backgroundColor = [UIColor redColor];
    [btn setImage:[UIImage imageNamed:@"Write"] forState:UIControlStateNormal];
    [btn setTitle:@"写新邮件" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor colorWithRed:21/255.0 green:132/255.0 blue:254/255.0 alpha:1.f] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(newMailWithAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    
    UITapGestureRecognizer *gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(newMailWithAction:)];
    [self.bottomView addGestureRecognizer:gesture];
    
}

#pragma mark -- newMailWithAction
- (void) newMailWithAction : (UIButton *) sender
{
    NSLog(@"点击了新启邮件");
    NewViewController *vc = [[NewViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}


#pragma mark -- setupWithRiht
- (void) setupWithRiht
{
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 20, 20)];
    [btn setImage:[UIImage imageNamed:@"more_grey"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(setupWithAction) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    
}

#pragma mark -- setupWithAction
- (void) setupWithAction
{
    NSLog(@"点击了更多");
}


#pragma mark -- uitableview delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 2;
    }else
    {
        return 5;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 48;
    }else
    {
        return 25;
    }
}


- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 48)];
        view.backgroundColor = [UIColor whiteColor];
        
        /* 🔍 搜索 */
        UITextField *field = [[UITextField alloc] initWithFrame:CGRectMake(16, 8, self.view.frame.size.width - 32, 32)];
        field.backgroundColor = [UIColor colorWithRed:243/255.0 green:245/255.0 blue:249/255.0 alpha:1.f];
        field.placeholder = @"  🔍 搜索";
        field.delegate = self;
        field.layer.cornerRadius = 5;
        field.layer.masksToBounds = YES;
        [view addSubview:field];
        return view;
    }else
    {
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 25)];
        view.backgroundColor = [UIColor colorWithRed:243/255.0 green:245/255.0 blue:249/255.0 alpha:1.f];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(16, 5, 100, 15)];
        label.text = @"文件夹";
        label.textColor = [UIColor lightGrayColor];
        label.font = [UIFont systemFontOfSize:15];
        [view addSubview:label];
        return view;
    }
}


- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HomeCell *cell = [[[NSBundle mainBundle]loadNibNamed:@"HomeCell" owner:self options:nil] lastObject];
    
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            cell.iconImageView.image = [UIImage imageNamed:@"recept"];
            cell.titleLab.text = @"收件箱";
            cell.backLog = 3;
            cell.total = 21;
            return cell;
        }else
        {
            cell.iconImageView.image = [UIImage imageNamed:@"star-"];
            cell.titleLab.text = @"已标星";
            cell.backLog = 0;
            cell.total = 3;
            return cell;
        }
    }else
    {
        NSString *iconimageNameStr, *titleStr;
        NSInteger backLog,total;
        switch (indexPath.row) {
            case 0:
            {
                iconimageNameStr = @"Draft_box";
                titleStr = @"草稿箱";
                backLog = 0;
                total = 0;
            }
                break;
            case 1:
            {
                iconimageNameStr = @"occur";
                titleStr = @"已发送";
                backLog = 0;
                total = 0;
            }
                break;
            case 2:
            {
                iconimageNameStr = @"deleted";
                titleStr = @"已删除";
                backLog = 0;
                total = 0;
            }
                break;
            case 3:
            {
                iconimageNameStr = @"junk_mail";
                titleStr = @"垃圾邮件";
                backLog = 0;
                total = 0;
            }
                break;
            default:
            {
                iconimageNameStr = @"abnormal";
                titleStr = @"异常邮件";
                backLog = 0;
                total = 0;
            }
                break;
        }
        
        cell.iconImageView.image = [UIImage imageNamed:iconimageNameStr];
        cell.titleLab.text = titleStr;
        cell.backLog = backLog;
        cell.total = total;
        return cell;
    }
    
}

#pragma mark -- uitableview DataSource
- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ListViewController *vc = [[ListViewController alloc] init];
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            vc.title = @"收件箱";
            NSLog(@"点击了收件箱");
        }else
        {
            vc.title = @"已标星";
            NSLog(@"点击了已标星");
        }
    }else
    {
        switch (indexPath.row) {
            case 0:
            {
                vc.title = @"草稿箱";
                NSLog(@"点击了草稿箱");
            }
                break;
            case 1:
            {
                vc.title = @"已发送";
                NSLog(@"点击了已发送");
            }
                break;
            case 2:
            {
                vc.title = @"已删除";
                NSLog(@"点击了已删除");
            }
                break;
            case 4:
            {
                vc.title = @"垃圾邮件";
                NSLog(@"点击了垃圾邮件");
            }
                break;
            default:
            {
                vc.title = @"异常邮件";
                NSLog(@"点击了异常邮件");
            }
                break;
        }
        
    }
   
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark -- textfiled delegate
//- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
//{
//    [textField becomeFirstResponder];
//    return YES;
//}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.view endEditing:YES];
    return YES;
}

#pragma mark -- getter
- (UITableView *)selfTableview
{
    if (!_selfTableview) {
        _selfTableview = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds];
        _selfTableview.backgroundColor = [UIColor colorWithRed:243/255.0 green:245/255.0 blue:249/255.0 alpha:1.f];
        _selfTableview.delegate = self;
        _selfTableview.dataSource = self;
        _selfTableview.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _selfTableview;
}

- (UIView *)bottomView
{
    if (!_bottomView) {
        _bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height - 48, self.view.frame.size.width, 48)];
        _bottomView.backgroundColor = [UIColor whiteColor];
    
    }
    return _bottomView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
