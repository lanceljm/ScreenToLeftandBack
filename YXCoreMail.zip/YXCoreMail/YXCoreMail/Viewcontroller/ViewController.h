//
//  ViewController.h
//  YXCoreMail
//
//  Created by ljm on 2018/8/7.
//  Copyright © 2018年 yxtech.ios. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ViewController : UIViewController


@end

